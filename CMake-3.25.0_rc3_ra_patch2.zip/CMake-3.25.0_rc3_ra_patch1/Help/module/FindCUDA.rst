.. cmake-module:: ../../Modules/FindCUDA.cmake
