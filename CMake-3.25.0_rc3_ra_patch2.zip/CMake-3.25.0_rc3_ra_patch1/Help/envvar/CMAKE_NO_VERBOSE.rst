CMAKE_NO_VERBOSE
----------------

.. versionadded:: 3.14

Disables verbose output from CMake when :envvar:`VERBOSE` environment variable
is set.

Only your build tool of choice will still print verbose output when you start
to actually build your project.
